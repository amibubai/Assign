package com.flp.pms.view;

import java.util.Scanner;

import com.flp.pms.domain.Product;
import com.flp.pms.service.IProductService;
import com.flp.pms.service.ProductServiceImpl;

public class BootClass {

	public static void main(String[] args) {
		menuSelection();

	}
	
	public static void menuSelection(){
		int option,op;
		String choice=null,ch=null;
		Scanner sc=new Scanner(System.in);
		UserInteraction userInteraction=new UserInteraction();
		IProductService iProductService=new ProductServiceImpl();
		do{
			System.out.println("......... Product Menu.............");
			System.out.println("1.Create Product"+
					"\n2.Modify Product"+
					"\n3.Remove Product"+
					"\n4.View All Product"+
					"\n5.Search Product"+
					"\n6.Exit");
			System.out.println("Enter your option:");
			option=sc.nextInt();
			
			switch(option){
				case 1:
					Product product=userInteraction.addProduct(iProductService.getAllCategory(),
							iProductService.getAllSubCategory(),iProductService.getAllSupplier(),
							iProductService.getAllDiscounts());
					iProductService.addProduct(product);
					
					break;
				case 2:
						 int uproductId=userInteraction.getProductId();
						 Product uproduct=iProductService.searchProductById(uproductId);
						 System.out.println("............Update Menu............");
						 System.out.println("1.By Product Name" + "\n2.By Expiry Date" + "\n3. By Maximum Retail Price"
									+ "\n4.By Rating" + "\n5.By Category");
							System.out.println("Enter your option:");
							option = sc.nextInt();
							switch (option) 
							{
								case 1:
									String name=userInteraction.getUpdateProductName();
									iProductService.updateProductName(uproduct, name);
									break;
								case 2:
									
							
							}
						 break;
					
				 
				case 3:
					int productId=userInteraction.deleteProduct();
					 iProductService.delectProduct(productId);
					 userInteraction.getDeleteStatus(iProductService.delectProduct(productId));
					break;
				case 4:
					System.out.println(iProductService.getAllProducts());
					break;
				case 5:
					 do
					 {
						 System.out.println("........ Delete Menu.................");
					System.out.println("1.By Name"+
								"\n2.By Supplier/Producer"+
								"\n3.By Category"+
								"\n4.By SubCategory"+
								"\n5.By Ratings");
					System.out.println("Enter your option:");
					op=sc.nextInt();
					switch(op)
					{
						case 1:
							String productName=userInteraction.getProductName();
							Product searchProduct=iProductService.searchProductName(productName);
							userInteraction.showSearchProduct(searchProduct);
							break;
							
						case 2:
							String supplierName=userInteraction.getSupplierName();
							Product searchProductBySupplier=iProductService.searchProductBySupplier(supplierName);
							userInteraction.showSearchProduct(searchProductBySupplier);
							break;
						case 3:
							String catName=userInteraction.getcategoryName();
							Product searchProductByCategory=iProductService.searchProductByCategory(catName);
							userInteraction.showSearchProduct(searchProductByCategory);
							break;	
						 case 4:
							String subcatName=userInteraction.getSubcategoryName();
							Product searchProductBySubCategory=iProductService.searchProductBySubCategory(subcatName);
							userInteraction.showSearchProduct(searchProductBySubCategory);
							break;	 
							
						 case 5:
								float rating=userInteraction.getProductRating();
								Product searchProductByRating=iProductService.searchProductByRating(rating);
								userInteraction.showSearchProduct(searchProductByRating);
								break;		
					}
				 
					
					System.out.println("You wish to continue?[Y|N]");
					ch= sc.next();
				}while(ch.charAt(0)=='y'||ch.charAt(0)=='Y');
					 break;
				case 6:
					System.exit(0);
			}
			System.out.println("You wish to continue?[Y|N]");
			choice= sc.next();
		}while(choice.charAt(0)=='y'||choice.charAt(0)=='Y');
	}
	
	
	
	

}
