package com.flp.pms.service;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;

import com.flp.pms.dao.IProductDao;
import com.flp.pms.dao.ProductDaoImplForMap;
import com.flp.pms.domain.Category;
import com.flp.pms.domain.Discount;
import com.flp.pms.domain.Product;
import com.flp.pms.domain.SubCategory;
import com.flp.pms.domain.Supplier;
import com.flp.pms.util.Validate;

public class ProductServiceImpl implements IProductService {

	private IProductDao iProductDao = new ProductDaoImplForMap();

	public List<Category> getAllCategory() {
		return iProductDao.getAllCategory();
	}

	public List<SubCategory> getAllSubCategory() {
		return iProductDao.getAllSubCategory();
	}

	public List<Discount> getAllDiscounts() {

		return iProductDao.getAllDiscounts();
	}

	public List<Supplier> getAllSupplier() {

		return iProductDao.getAllSuppliers();
	}

	public void addProduct(Product product) {
		Map<Integer, Product> maps = iProductDao.getAllProducts();
		boolean flag = false;
		Set<Integer> product_IDS = maps.keySet();
		int product_id_generated = generateProductId();

		// Generate unique Product Id
		if (!maps.isEmpty()) {
			do {

				product_id_generated = generateProductId();
				for (Integer product_Id : product_IDS) {
					if (product_Id == product_id_generated) {
						flag = true;
						break;
					}
				}
			} while (flag);

		}
		product.setProductId(product_id_generated);

		iProductDao.addProduct(product);
	}

	public int generateProductId() {
		return (int) (Math.random() * 10000);
	}

	public Map<Integer, Product> getAllProducts() {
		return iProductDao.getAllProducts();
	}

	public List<Product> getAllProductsList() {
		Collection<Product> collectionProduct = getAllProducts().values();
		List<Product> listProducts = new ArrayList<Product>();
		for (Product product : collectionProduct)
			listProducts.add(product);
		return listProducts;
	}

	public boolean delectProduct(int productId) {
		Scanner sc = new Scanner(System.in);

		Map<Integer, Product> maps = iProductDao.getAllProducts();
		boolean flag = false;
		List<Product> products = getAllProductsList();
		for (Product product : products) {
			if (product.getProductId() == productId) {

				maps.remove(product.getProductId(), product);
				return true;

			}
		}
		return false;

	}

	public Product searchProductName(String productName) {
		Product searchProduct = null;
		List<Product> productList = getAllProductsList();
		for (Product product : productList) {
			if (product.getProductName().equalsIgnoreCase(productName)) {
				searchProduct = product;
				 
			}
		}
		return searchProduct;

	}

	public Product searchProductBySupplier(String supplierName) {
		Product searchProduct = null;
		List<Product> productList = getAllProductsList();

		for (Product product : productList) {
			 
			if (product.getSupplier().getFirstName().equalsIgnoreCase(supplierName))
					{
					searchProduct = product;
				    }
		}
		return searchProduct;

	}

	public Product searchProductBySubCategory(String subCategory) {
		
		   Product searchProductBySubCat = null; 
		   List<Product> productList = getAllProductsList();
		   
		   for (Product product : productList) {
		  
		   if(product.getSubCategory().getSub_category_Name().equalsIgnoreCase(subCategory))
		   { 
			   searchProductBySubCat = product; 
		   }
		   }
		  return searchProductBySubCat;
	}

	public Product searchProductByCategory(String categoryName) {
		 Product searchProductByCat = null; 
		   List<Product> productList = getAllProductsList();
		   
		   for (Product product : productList) {
		  
		   if(product.getCategory().getCategory_Name().equalsIgnoreCase(categoryName))
		   { 
			   searchProductByCat = product; 
		   }
		   }
		  return searchProductByCat;
		 
	}

	public Product searchProductByRating(float rating) {
		Product searchProductByRating = null; 
		   List<Product> productList = getAllProductsList();
		   
		   for (Product product : productList) {
		  
		   if(product.getRatings()==rating)
		   { 
			   searchProductByRating = product; 
		   }
		   }
		  return searchProductByRating;
	 
	}
	
	public Product searchProductById(int productId) {
		Product searchProductById = null; 
		   List<Product> productList = getAllProductsList();
		   
		   for (Product product : productList) {
		  
		   if(product.getProductId()==productId)
		   { 
			   searchProductById = product; 
		   }
		   }
		  return searchProductById;
	 
	}

	public Map<Integer, Product> updateProductName(Product p, String pName) {
		
		return null;
		
	}

}
